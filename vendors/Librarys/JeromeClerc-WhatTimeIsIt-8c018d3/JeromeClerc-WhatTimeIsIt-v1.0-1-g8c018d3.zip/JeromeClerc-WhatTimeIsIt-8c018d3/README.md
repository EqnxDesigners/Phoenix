WhatTimeIsIt
============

jQuery plugin for selecting time in a form

Demo here : http://jeromeclerc.github.io/WhatTimeIsIt/
